package com.coderhouse.dao;

import org.springframework.stereotype.Service;

import com.coderhouse.models.Alumno;
import com.coderhouse.models.Cursos;

import jakarta.persistence.EntityManager; // hibernet
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service // le esta diciendo a Spring boot que va a funcionar como un servicio
public class DaoFactory {
	
	
	@PersistenceContext
	private EntityManager em;

	
	@Transactional
	public void persistirAlumno(Alumno alumno) {
		em.persist(alumno);
		
	}
	
	@Transactional
	public void persistirCurso (Cursos curso) {
		em.persist(curso);
		
	}
}
