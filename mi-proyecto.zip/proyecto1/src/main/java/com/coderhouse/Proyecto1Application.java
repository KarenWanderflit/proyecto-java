package com.coderhouse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto1Application  implements CommandLineRunner{
	
	@Autowired
	private DaoFactoy dao;

	public static void main(String[] args) {
		SpringApplication.run(Proyecto1Application.class, args);
	}
	
	@Override
	public void run(String...arg) throws Exception  {
		try {
			Cursos curso1 = new Curso("Java")
			
		} catch(Exception err) {
			err.getMessage();
		}
		
		
		
		
		}
	
	

}
