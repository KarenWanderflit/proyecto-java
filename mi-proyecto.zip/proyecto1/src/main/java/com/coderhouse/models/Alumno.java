package com.coderhouse.models;

import java.time.LocalDateTime;
import java.util.ArrayList;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;


@Entity
@Table(name= "Alumnos")
public class Alumno {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // hace que el id sea autoincremental
	private Long id;
	
	@Column(name = "Nombre", nullable = false)
    private String nombre;
	
	@Column(name = "Apellido", nullable = false)
    private string apellido;
	
	@Column(name = "DNI", nullable = false, unique= true)
    private int dni;
	
	@Column(name = "Legajo", nullable = false, unique= true)
    private String legajo;
	
	@Column(name = "Edad")
    private int edad;
	
	@ManyToMany(mappedBy = "alumnos", fetch = FetchType.EAGER)
    private List <Curso> cursos = new ArrayList<>();
    
    
    private LocalDateTime createAt; // me da la hora exacta al momento de creacion
	public Alumno() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Alumno(Long id, String nombre, string apellido, int dni, String legajo, int edad, List<Curso> cursos,
			LocalDateTime createAt) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.legajo = legajo;
		this.edad = edad;
		this.cursos = cursos;
		this.createAt = createAt;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public string getApellido() {
		return apellido;
	}
	public void setApellido(string apellido) {
		this.apellido = apellido;
	}
	public int getDni() {
		return dni;
	}
	public void setDni(int dni) {
		this.dni = dni;
	}
	public String getLegajo() {
		return legajo;
	}
	public void setLegajo(String legajo) {
		this.legajo = legajo;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public List<Cursos> getCursos() {
		return cursos;
	}
	public void setCursos(List<Cursos> cursos) {
		this.cursos = cursos;
	}
	public LocalDateTime getCreateAt() {
		return createAt;
	}
	public void setCreateAt(LocalDateTime createAt) {
		this.createAt = createAt;
	}
	@Override
	public String toString() {
		return "Alumno [id=" + id + ", nombre=" + nombre + ", dni=" + dni + ", legajo=" + legajo + ", edad=" + edad
				+ ", createAt=" + createAt + "]";
	}
    
    
    
    
}
