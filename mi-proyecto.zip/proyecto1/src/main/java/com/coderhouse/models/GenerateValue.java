package com.coderhouse.models;

public @interface GenerateValue {

}
